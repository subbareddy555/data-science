Problem Statement - You are a cab rental start-up company. 
You have successfully run the pilot project and now want to launch your cab service across the country. 
You have collected the historical data from your pilot project and now have a requirement to apply analytics for fare prediction. 
You need to design a system that predicts the fare amount for a cab ride in the city.


